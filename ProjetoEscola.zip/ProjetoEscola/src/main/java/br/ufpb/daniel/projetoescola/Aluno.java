package br.ufpb.daniel.projetoescola;
import java.util.Date;

public class Aluno {
    private Date dataNascimento;
}


