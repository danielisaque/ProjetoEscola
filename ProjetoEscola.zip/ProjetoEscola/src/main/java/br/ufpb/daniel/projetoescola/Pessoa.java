package br.ufpb.daniel.projetoescola;

public class Pessoa {
    private String nome;
    private int matricula;
}
